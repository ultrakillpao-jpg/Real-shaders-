package com.realismo.neural
import android.graphics.SurfaceTexture
import android.opengl.*
import android.util.Log
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

object Cfg { @Volatile var k = 1f; @Volatile var m = 1f; @Volatile var li = 1f; @Volatile var mode = 1f }

const val VS = """
attribute vec4 aPos; attribute vec2 aTex; uniform mat4 uM; varying vec2 q;
void main(){ gl_Position=aPos; q=(uM*vec4(aTex,0.,1.)).xy; }
"""
const val FS = """
#extension GL_OES_EGL_image_external : require
precision mediump float;
uniform samplerExternalOES T; uniform vec2 tx; uniform vec4 st; uniform float tm; varying vec2 q;
float lm(vec3 c){return dot(c,vec3(.299,.587,.114));}
vec3 S(vec2 p){return texture2D(T,p).rgb;}
void main(){
 float K=st.x,M=st.y,LI=st.z,md=floor(st.w+.5);
 vec3 c=S(q),e=S(q+vec2(tx.x,0.)),w0=S(q-vec2(tx.x,0.)),s=S(q+vec2(0.,tx.y)),n0=S(q-vec2(0.,tx.y));
 vec3 b=(c+e+w0+s+n0)/5.; float ed=clamp(length(c-b)*6.,0.,1.);
 c+=(c-b)*1.8*K; float l=lm(c);
 vec3 n=normalize(vec3((lm(w0)-lm(e))*5.,(lm(n0)-lm(s))*5.,1.));
 float wa=0.; vec2 gd=vec2(0.);
 for(int i=0;i<8;i++){ float a=float(i)*.785398; vec2 d=vec2(cos(a),sin(a)); float v=lm(S(q+d*tx*6.)); wa+=v; gd+=d*v; }
 wa/=8.; gd/=8.;
 float occ=clamp(1.-(wa-l)*2.*K,.4,1.1);
 float sg=clamp(length(gd)*20.,0.,1.);
 vec3 L1=normalize(vec3(gd*14.,.35));
 float d1=max(dot(n,L1),0.)*sg;
 float sp1=pow(max(dot(n,normalize(L1+vec3(0.,0.,1.))),0.),32.)*sg;
 vec2 tp=vec2(.5+.35*cos(tm*.6),.5+.25*sin(tm*.8)); vec2 dt=tp-q;
 float at=(.75+.25*sin(tm*17.)*sin(tm*6.1))/(1.+dot(dt,dt)*9.);
 vec3 L2=normalize(vec3(dt,.25));
 float d2=max(dot(n,L2),0.)*at;
 float sp2=pow(max(dot(n,normalize(L2+vec3(0.,0.,1.))),0.),32.)*at;
 float mx=max(c.r,max(c.g,c.b)),mn=min(c.r,min(c.g,c.b)),sat=(mx-mn)/(mx+.001);
 float metal=clamp(smoothstep(.6,.12,sat)*smoothstep(.1,.42,l)+ed*.45,0.,1.);
 float skin=smoothstep(.12,.3,sat)*step(c.g,c.r)*step(c.b,c.g)*smoothstep(.15,.4,l);
 vec3 o=c*occ*(.68+LI*(d1*1.2+d2*.9));
 o+=(sp1*vec3(1.,.9,.75)+sp2*vec3(1.,.2,.12))*M*(.2+metal*2.2)*2.*LI;
 o+=skin*vec3(.22,.07,.04)*K; o+=vec3(1.,.15,.1)*d2*.35*LI;
 vec3 bl=max(S(q+vec2(tx.x*14.,0.))-.55,0.)+max(S(q-vec2(tx.x*14.,0.))-.55,0.)+max(S(q+vec2(0.,tx.y*14.))-.55,0.)+max(S(q-vec2(0.,tx.y*14.))-.55,0.);
 o+=bl*.35*K;
 float g=lm(o); vec3 gr=o;
 if(md>.5&&md<1.5) gr=mix(vec3(g),o,.5)*vec3(.9,1.06,.86);
 else if(md>1.5&&md<2.5){ vec3 R0=vec3(.88,.04,.03); gr=g<.5?mix(vec3(0.),R0,g*2.):mix(R0,vec3(1.),(g-.5)*2.); }
 else if(md>2.5) gr=mix(vec3(g),o,.7)*vec3(1.3,.5,.5);
 o=mix(o,gr,.85*step(.5,md));
 o=(o-.5)*1.1+.5; o*=1.1-.55*dot(q-.5,q-.5)*2.;
 gl_FragColor=vec4(max(o,0.),1.);
}
"""

class FxRenderer(private val w: Int, private val h: Int, private val onSurface: (Surface) -> Unit) : GLSurfaceView.Renderer {
  var view: GLSurfaceView? = null
  private var prog = 0; private var tex = 0; private var st: SurfaceTexture? = null
  private val mat = FloatArray(16)
  private fun fb(a: FloatArray): FloatBuffer = ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(a); position(0) }
  private val pos = fb(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
  private val tc = fb(floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f, 1f, 1f))
  private fun sh(t: Int, s: String): Int {
    val x = GLES20.glCreateShader(t); GLES20.glShaderSource(x, s); GLES20.glCompileShader(x)
    Log.e("fx", GLES20.glGetShaderInfoLog(x)); return x
  }
  private fun u(n: String) = GLES20.glGetUniformLocation(prog, n)
  private fun attr(n: String, b: FloatBuffer) {
    val p = GLES20.glGetAttribLocation(prog, n); GLES20.glEnableVertexAttribArray(p)
    GLES20.glVertexAttribPointer(p, 2, GLES20.GL_FLOAT, false, 0, b)
  }
  override fun onSurfaceCreated(gl: GL10?, c: EGLConfig?) {
    prog = GLES20.glCreateProgram()
    GLES20.glAttachShader(prog, sh(GLES20.GL_VERTEX_SHADER, VS)); GLES20.glAttachShader(prog, sh(GLES20.GL_FRAGMENT_SHADER, FS))
    GLES20.glLinkProgram(prog)
    val t = IntArray(1); GLES20.glGenTextures(1, t, 0); tex = t[0]
    GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
    GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
    GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
    GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
    GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
    st?.release()
    val s = SurfaceTexture(tex); s.setDefaultBufferSize(w, h)
    s.setOnFrameAvailableListener { view?.requestRender() }
    st = s; onSurface(Surface(s))
  }
  override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) { GLES20.glViewport(0, 0, width, height) }
  override fun onDrawFrame(gl: GL10?) {
    val s = st ?: return
    s.updateTexImage(); s.getTransformMatrix(mat)
    GLES20.glUseProgram(prog)
    GLES20.glActiveTexture(GLES20.GL_TEXTURE0); GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
    GLES20.glUniformMatrix4fv(u("uM"), 1, false, mat, 0)
    GLES20.glUniform1i(u("T"), 0)
    GLES20.glUniform2f(u("tx"), 1f / w, 1f / h)
    GLES20.glUniform4f(u("st"), Cfg.k, Cfg.m, Cfg.li, Cfg.mode)
    GLES20.glUniform1f(u("tm"), (System.nanoTime() / 1e9 % 1000).toFloat())
    attr("aPos", pos); attr("aTex", tc)
    GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
  }
}
