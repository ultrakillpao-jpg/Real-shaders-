package com.realismo.neural
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.opengl.GLSurfaceView
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.abs

class FxService : Service() {
  private var mp: MediaProjection? = null
  private var vd: VirtualDisplay? = null
  private var gv: GLSurfaceView? = null
  private var bb: TextView? = null
  private lateinit var wm: WindowManager
  private var on = true
  override fun onBind(i: Intent?): IBinder? = null

  @Suppress("DEPRECATION")
  override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
    val nm = getSystemService(NotificationManager::class.java)
    nm.createNotificationChannel(NotificationChannel("fx", "Realismo Neural", NotificationManager.IMPORTANCE_LOW))
    val n = Notification.Builder(this, "fx").setContentTitle("Realismo Neural ativo").setSmallIcon(android.R.drawable.ic_menu_view).build()
    if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(1, n)
    if (i == null || gv != null) return START_NOT_STICKY
    val data = i.getParcelableExtra<Intent>("data") ?: run { stopSelf(); return START_NOT_STICKY }
    val main = Handler(Looper.getMainLooper())
    val m = (getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).getMediaProjection(i.getIntExtra("code", 0), data)
    m.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, main)
    mp = m
    wm = getSystemService(WINDOW_SERVICE) as WindowManager
    val dm = DisplayMetrics(); wm.defaultDisplay.getRealMetrics(dm)
    val w = (dm.widthPixels * 0.75f).toInt() / 2 * 2
    val h = (dm.heightPixels * 0.75f).toInt() / 2 * 2

    val r = FxRenderer(w, h) { s ->
      main.post {
        val d = vd
        if (d == null) vd = m.createVirtualDisplay("fx", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, s, null, null)
        else d.surface = s
      }
    }
    val g = GLSurfaceView(this)
    r.view = g
    g.setEGLContextClientVersion(2)
    g.setZOrderOnTop(true)
    g.holder.setFormat(PixelFormat.TRANSLUCENT)
    g.setRenderer(r)
    g.renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
    gv = g
    val T = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    val lp = WindowManager.LayoutParams(-1, -1, T,
      WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
      WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
    wm.addView(g, lp)

    val b = TextView(this).apply {
      text = "FX"; setTextColor(Color.WHITE); gravity = Gravity.CENTER; textSize = 14f
      setBackgroundColor(0xCCE5251B.toInt()); setPadding(28, 28, 28, 28)
    }
    val bp = WindowManager.LayoutParams(-2, -2, T,
      WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
    bp.gravity = Gravity.TOP or Gravity.START; bp.x = 0; bp.y = 300
    var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false; var t0 = 0L
    b.setOnTouchListener { _, e ->
      when (e.action) {
        MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = bp.x; oy = bp.y; moved = false; t0 = e.eventTime }
        MotionEvent.ACTION_MOVE -> {
          val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
          if (abs(dx) > 12 || abs(dy) > 12) moved = true
          if (moved) { bp.x = ox + dx; bp.y = oy + dy; wm.updateViewLayout(b, bp) }
        }
        MotionEvent.ACTION_UP -> if (!moved) {
          if (e.eventTime - t0 > 600) { Cfg.mode = (Cfg.mode + 1f) % 4f; b.text = "FX" + Cfg.mode.toInt() }
          else {
            on = !on
            g.visibility = if (on) View.VISIBLE else View.INVISIBLE
            if (!on) vd?.surface = null
            b.alpha = if (on) 1f else 0.5f
          }
        }
      }
      true
    }
    bb = b
    wm.addView(b, bp)
    return START_NOT_STICKY
  }

  override fun onDestroy() {
    try { gv?.let { wm.removeView(it) }; bb?.let { wm.removeView(it) } } catch (e: Exception) {}
    vd?.release(); mp?.stop(); super.onDestroy()
  }
}
