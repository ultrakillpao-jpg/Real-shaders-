package com.realismo.neural
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
  private val REQ = 7
  override fun onCreate(s: Bundle?) {
    super.onCreate(s)
    val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48); setBackgroundColor(Color.BLACK) }
    fun tv(t: String) = TextView(this).apply { text = t; setTextColor(Color.WHITE); textSize = 15f; setPadding(0, 0, 0, 24) }
    fun bar(n: String, v: Float, set: (Float) -> Unit) {
      l.addView(tv(n))
      l.addView(SeekBar(this).apply {
        max = 200; progress = (v * 100).toInt()
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
          override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { set(p / 100f) }
          override fun onStartTrackingTouch(s: SeekBar?) {}
          override fun onStopTrackingTouch(s: SeekBar?) {}
        })
      })
    }
    l.addView(tv("Realismo Neural\n\n1. Libere \"Sobrepor a outros apps\".\n2. Toque em Ativar. Na janela do Android, escolha compartilhar UM APP (o jogo), para a imagem não se repetir.\n3. Abra o jogo. Toque no botão FX para ligar/desligar; segure para trocar o estilo (0 original, 1 Manhunt, 2 ULTRAKILL, 3 sangue)."))
    bar("Intensidade", Cfg.k) { Cfg.k = it }
    bar("Brilho dos metais", Cfg.m) { Cfg.m = it }
    bar("Luz dinâmica", Cfg.li) { Cfg.li = it }
    l.addView(Button(this).apply { text = "Ativar"; setOnClickListener { go() } })
    setContentView(l)
  }
  private fun go() {
    if (!Settings.canDrawOverlays(this)) {
      startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName))); return
    }
    startActivityForResult((getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).createScreenCaptureIntent(), REQ)
  }
  @Deprecated("ok")
  override fun onActivityResult(rq: Int, rc: Int, d: Intent?) {
    super.onActivityResult(rq, rc, d)
    if (rq == REQ && rc == RESULT_OK && d != null) {
      startForegroundService(Intent(this, FxService::class.java).putExtra("code", rc).putExtra("data", d))
      moveTaskToBack(true)
    }
  }
}
